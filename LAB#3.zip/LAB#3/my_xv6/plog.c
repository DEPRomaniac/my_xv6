#include "types.h"
#include "user.h"
#include "fcntl.h"

int main()
{
    plog();
    exit();
}